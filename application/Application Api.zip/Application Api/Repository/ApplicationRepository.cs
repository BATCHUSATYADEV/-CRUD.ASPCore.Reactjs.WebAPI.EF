﻿using Application_Api.Interface;
using Application_Api.Model;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Web.Http;

namespace Application_Api.Repository
{
    public class ApplicationRepository:IApplication
    {
        List<Application> lisMembers = new List<Application>
        {
            new Application{ApplicationId=1, ApplicationName="SATYA", ApplicationEmail="Shah@gmail.com", ApplicationDob="02-07-2001" },
            new Application{ApplicationId=2, ApplicationName="deepU", ApplicationEmail="Shah@gmail.com", ApplicationDob="02-07-2001" },
            new Application{ApplicationId=3, ApplicationName="ASLESHA", ApplicationEmail="Shah@gmail.com", ApplicationDob="02-07-2001" },
            new Application{ApplicationId=4, ApplicationName="DEV", ApplicationEmail="Shah@gmail.com", ApplicationDob="02-07-2001" },

        };
       

        public List<Application> GetAllApplication()
        {
            return lisMembers;
        }

       

        public Application GetApplication(int id)
        {
            
            return lisMembers.FirstOrDefault(x => x.ApplicationId == id);
        }
        public Boolean deleteStudent(int id)
        {
            Application application =this.GetApplication(id);
            if (application == null)
            {
                return lisMembers.Remove(application);
            }
            return lisMembers.Remove(application); 
        }



 

        public List<Application> updateemployee(int id,Application app)
        {
            Application application = GetApplication(app.ApplicationId);
            if (application != null)
            {
                application.ApplicationName = app.ApplicationName;
                application.ApplicationEmail = app.ApplicationEmail;
                application.ApplicationDob = app.ApplicationDob;
                return lisMembers;

            }
            return null;
        }

        public List<Application> createapp(Application app)
        {
            lisMembers.Add(app);
            return lisMembers;
        }
    }
}
