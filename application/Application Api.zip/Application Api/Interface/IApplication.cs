﻿using Application_Api.Model;
using Microsoft.AspNetCore.Mvc;

namespace Application_Api.Interface

{
    public interface IApplication
    {
        List<Application> GetAllApplication();
        Application GetApplication(int id);
        Boolean deleteStudent(int id);

        List<Application> updateemployee(int id, Application app);

        List<Application> createapp(Application app);
    }
}
