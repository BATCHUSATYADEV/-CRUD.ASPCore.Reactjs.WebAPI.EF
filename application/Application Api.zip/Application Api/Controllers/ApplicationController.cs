﻿using Application_Api.Interface;
using Application_Api.Model;
using Application_Api.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Application_Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApplicationController : ControllerBase
    {
        private IApplication members = new ApplicationRepository();

        [HttpGet]
        public ActionResult<IEnumerable<Application>> GetAllMembers()
        {
            return members.GetAllApplication();
        }

        [HttpGet]
        [Route("ByID")]
        public ActionResult<Application> GetApplicaltion(int id)
        {
            return members.GetApplication(id);
        }

        [HttpDelete("{id:int}")]
        public Boolean DeleteStudent(int id)
        {
            //var employeeToDelete = await ApplicationRepository.GetApplication(id);
            return members.deleteStudent(id);
        }

        [HttpPut("{id:int}")]
        public ActionResult<IEnumerable<Application>> UpdateEmployee(int id,Application app)
        {
            return members.updateemployee(id,app);
        }

        [HttpPost]

        public ActionResult<IEnumerable<Application>> createapp(Application app)
        {
           return members.createapp(app);
        }


    }
}


