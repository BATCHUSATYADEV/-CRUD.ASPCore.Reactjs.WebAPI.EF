﻿namespace Application_Api.Model
{
    public class Application
    {
        public int ApplicationId
        {
            get; set; 
        }
        public String ApplicationName
        {
            get; set;
        }
        public String ApplicationEmail
        {
            get; set;
        }
        public String ApplicationDob
        {
            get; set;
        }
    }
}
